<template>
    <button
        class="w-full flex justify-center items-center px-4 py-3 bg-brand-green border border-transparent rounded-md font-semibold text-base text-black uppercase tracking-widest hover:bg-brand-green-dark focus:outline-none focus:ring-2 focus:ring-brand-green focus:ring-offset-2 dark:ring-offset-gray-800 transition ease-in-out duration-150"
    >
        <slot />
    </button>
</template>